<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adopt Dogs</title>
    <link rel="stylesheet" href="dog.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        /* Navigációs sáv stílusa */
        .Nav {
            background-color: #333;
            overflow: hidden;
        }

        .Nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 70px;
        }

        .Nav li {
            margin: 0;
            padding: 0;
        }

        .Nav li a {
            text-decoration: none;
            color: white;
            font-weight: bold;
            padding: 15px 20px;
            transition: background-color 0.3s;
        }

        .Nav li a:hover {
            background-color: #555;
        }

        /* A gomb stílusa a navigációs sávon */
        .Home-btn {
            background-color: #f44336;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .Home-btn:hover {
            background-color: #d32f2f;
        }

        /* A fejléc és tartalom tartalmazó div stílusa */
        #HomeSection {
            background-image: url("images/DogAdopt.jpg");
            background-size: cover;
            background-position: center;
            text-align: center;
            padding: 100px 0;
        }

        .Company {
            font-size: 36px;
            color: #f44336;
            margin-bottom: 20px;
        }

        .title {
            font-size: 24px;
            color: #fff;
            margin-bottom: 30px;
        }

        /* Lábléc stílusa */
        .Footer {
            background-color: #333;
            color: white;
            padding: 20px 0;
            text-align: center;
        }

        /* Új stílus a tartalomhoz */
        .content {
            text-align: center;
            margin: 0 auto;
            max-width: 800px;
            padding: 20px;
        }

        .image_1 {
            max-width: 100%;
            height: auto;
            display: block;
            margin: 0 auto;
        }
    </style>
</head>

<body>

    <!-- Navigation Bar -->
    <div class="Nav">
        <ul>
            <li class="nav-list"><a href="index.php">Home</a></li>
            <li class="nav-list"><a href="User_about.php">About us</a></li>
            <li class="dropdown">
                <a href="User_services.php" class="dropbtn">Services</a>
                <div class="dropdown-content">
                    <a href="street.php">Adopt Dogs</a>
                    <a href="adopt.php">Sell dogs</a>
                </div>
            </li>
            <li class="nav-list"><a href="UserDonation.php">Contribute</a></li>
            <?php
            if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
            ?>
                <li class="nav-list-login"><a href="Logout.php">Signout</a></li>
            <?php }else{ ?>
                <li class="nav-list-login"><a href="Login.php">Login</a></li>
            <?php } ?>
        </ul>
    </div>

    <!-- Home section -->
    <div id="HomeSection">
        <div class="content">
            <h1 class="Company">Dogozz</h1>
            <h1 class="title">Let's save the dogs</h1>
            <button class="Home-btn">Inform about street dogs</button>
      

    <!-- Footer -->
    <?php include("footer.php"); ?>

</body>
</html>
