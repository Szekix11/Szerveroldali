
<?php

session_start();
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Adopt Dogs</title>
    <link rel="stylesheet" href="dog.css">
  </head>

<body>

  <!-- Navigation Bar -->

  <div class="Nav">
    <ul>
      <li class="nav-list"><a href="AdminHome.php">Home</a></li>
      <li class="nav-list"><a href="dog_table.php">Adopted Dogs</a></li>
      <li class="nav-list"><a href="AdminSold.php">Sold Dogs</a></li>
      <li class="nav-list"><a href="AdminDonation.php">Donation</a></li>
     

      <li class="nav-list-login"><a href="Logout.php">Signout</a></li>
   
    </ul>

  </div>

  </body>
</html>

 