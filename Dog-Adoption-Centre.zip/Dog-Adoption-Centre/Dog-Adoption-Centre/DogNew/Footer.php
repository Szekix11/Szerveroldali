<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adopt Dogs</title>
    <link rel="stylesheet" href="dog.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        /* Add it to your existing CSS file or link a new CSS file for styles */
        /* You can customize the styles below */

        body {
            margin: 0;
            padding: 0;
        }

        .Footer {
            background-color: #0a0a0a;
            width: 100%;
            padding: 20px 0;
            color: white;
            text-align: center;
            position: fixed;
            bottom: 0;
            left: 0;
        }

        .Footer h4 {
            margin: 10px 0;
        }

        .Footer a {
            text-decoration: none;
            color: white;
        }

        .Footer a:hover {
            text-decoration: underline;
        }

        .col-01,
        .col-02,
        .col-03 {
            width: 33.33%;
            padding: 20px;
        }

        .col-01 h4,
        .col-02 h4,
        .col-03 h4 {
            margin: 5px 0;
        }

        .sendQuery {
            display: block;
            margin: 0 auto;
            padding: 10px 20px;
            background-color: #333;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .sendQuery:hover {
            background-color: #555;
        }
    </style>
</head>

<body>

<!-- Footer -->

<div class="Footer">
    <div class="col-01">
        <h4>Contact us :</h4>
        <h4>Phone : 0712345689</h4>
        <h4>Mail : <a href="mailto:adoptdogs12345@gmail.com">adoptdogs12345@gmail.com</a></h4>
    </div>
    <div class="col-02">
        <h4><a href="#">Inform About street dog</a></h4>
        <h4><a href="#">Buy a dog for free</a></h4>
        <h4><a href="#">Contribute to us</a></h4>
    </div>
    <div class="col-03">
        <form>
            <h4>Write your queries</h4>
            <input type="text"/><br/>
            <button class="sendQuery">Send</button>
        </form>
    </div>
</div>

</body>
</html>
