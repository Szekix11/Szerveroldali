<?php
session_start();

$_SESSION = array();

session_destroy();

// Sikeres kijelentkezés üzenet
$message = "Sikeres kijelentkezés";

// JavaScript segítségével jelenítsd meg a pop-up ablakot
echo "<script>alert('$message'); window.location.href='login.php';</script>";
exit;
?>
