<?php
session_start();

// Ellenőrizd, hogy a felhasználó be van-e jelentkezve, és ha igen, átirányítsd őket az AdminHome.php oldalra
if (isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true) {
    header("location: AdminHome.php");
    exit;
}

include("config.php");

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    // Az űrlap elküldésekor
    $Username = $_POST['Username'];
    $Password = $_POST['Password'];

    // Ellenőrizd, hogy a felhasználónév még nem foglalt-e
    $check_query = "SELECT * FROM admin WHERE Username = '$Username'";
    $check_result = mysqli_query($link, $check_query);

    if ($check_result && mysqli_num_rows($check_result) > 0) {
        echo "A felhasználónév már foglalt!";
    } else {
        // Ha a felhasználónév még nem foglalt, akkor hozzáadhatod az adatbázishoz
        $insert_query = "INSERT INTO admin (Username, Password) VALUES ('$Username', '$Password')";
        $insert_result = mysqli_query($link, $insert_query);

        if ($insert_result) {
            echo "Sikeres regisztráció. Most már bejelentkezhet!";
        } else {
            echo "Hiba történt a regisztráció során.";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Regisztráció</title>
    <link rel="stylesheet" href="dog.css">
</head>
<body>

<!-- Navigációs sáv -->
<?php
include("Navbar.php");
?>

<div class="bg">
    <div class="box-form">
        <div class="box-login">
            <h4 class="register-topic">Regisztráció</h4>
            <form method="post">

                <input id="text" type="text" name="Username" class="form-login" placeholder="Felhasználónév"><br><br>
                <input id="text" type="Password" name="Password" class="form-login" placeholder="Jelszó"><br><br>

                <input id="button" type="submit" value="Regisztráció" class="btn-login"><br><br>

                <p class="swap">Már van fiókja? <a href="login.php">Jelentkezzen be</a></p><br><br>
            </form>
        </div>
    </div>
</div>

<!-- Footer -->
<?php
include("footer.php");
?>

</body>
</html>
