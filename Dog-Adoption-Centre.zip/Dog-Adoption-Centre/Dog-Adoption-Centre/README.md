Dog-Adoption-Centre
This is a website for adopting street dogs.

Creat a database names "dogs" and import the database from DB folder.
